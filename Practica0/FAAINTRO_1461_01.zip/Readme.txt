Hemos comentado todas las funciones print(), donde hacían imprimir todos los datos
necesarios para crear la clase Datos en python. Debido a que no sabiamos si dejarlos
puestos en la ejecución del programa o no, por eso están comentados
Esta práctica ha sido realizada por: Pablo Diez del Pozo y Alejandro Alcalá Álvarez
Pareja: 01
Grupo: 1461
